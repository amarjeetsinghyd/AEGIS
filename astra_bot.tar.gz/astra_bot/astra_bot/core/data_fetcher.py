import os
import json
import time
import requests
import pandas as pd
from datetime import datetime, timedelta

from astra_bot.config.settings import BROKER
ACTIVE_BROKER = (os.getenv("ACTIVE_BROKER") or BROKER).upper()

from astra_bot.core.logger import get_logger
logger = get_logger("data_fetcher")


class DataFetcher:
    """
    DataFetcher for KDO Architecture.
    Handles active instrument identification, index spot quote queries,
    and dynamic weekly option chain resolution.
    """
    def __init__(self, broker_adapter=None, instrument_repo=None):
        self.broker = broker_adapter
        self.repo = instrument_repo

    def get_active_instrument(self):
        """
        Determines active index based on day of week:
        - Mon (0), Tue (1), Fri (4) -> NIFTY (NSE / NFO)
        - Wed (2), Thu (3)        -> SENSEX (BSE / BFO)
        """
        weekday = datetime.now().weekday()
        if weekday in [2, 3]:
            return "SENSEX", "BFO"
        else:
            return "NIFTY", "NFO"

    def get_cash_index_token(self):
        name, exch = self.get_active_instrument()
        if name == "NIFTY":
            token = "26000"
            return token, "NIFTY", "NSE"
        else:
            token = "1" if ACTIVE_BROKER == "SHOONYA" else "99919000"
            return token, "SENSEX", "BSE"

    def get_index_ltp(self) -> float:
        """Queries live Index Spot LTP from WebSocket cache or REST fallback."""
        try:
            token, name, exchange = self.get_cash_index_token()
            if self.broker:
                provider = self.broker.market_data_provider if hasattr(self.broker, "market_data_provider") else self.broker
                quote = provider.get_quote(exchange, token)
                if isinstance(quote, dict):
                    price = quote.get("lp") or quote.get("ltp") or quote.get("c", 0.0)
                    if price > 0:
                        return float(price)
        except Exception as e:
            logger.error(f"Failed to fetch {name} LTP: {e}")
        return 0.0

    def get_weekly_option_tokens(self, target_index: str = None) -> pd.DataFrame:
        """
        Resolves dynamic weekly option chain for active index.
        Uses local SQLite DB lookup or falls back to Shoonya searchscrip API.
        """
        if target_index:
            name = target_index
            exch_seg = "BFO" if name == "SENSEX" else "NFO"
        else:
            name, exch_seg = self.get_active_instrument()

        df = pd.DataFrame()
        if self.repo:
            rows = self.repo.get_weekly_option_tokens(ACTIVE_BROKER, name, exch_seg)
            df = pd.DataFrame(rows) if rows else pd.DataFrame()

        # If DB lookup returns empty or incomplete option chain, fetch dynamic chain via searchscrip
        if (df.empty or len(df) < 5) and self.broker and hasattr(self.broker, "_api"):
            try:
                index_price = self.get_index_ltp()
                if index_price > 0:
                    step = 100 if name == "SENSEX" else 50
                    atm_strike = round(index_price / step) * step
                    strike_list = [atm_strike + (i * step) for i in range(-5, 16)]

                    dynamic_opts = []
                    for s_val in strike_list:
                        search_term = f"{name} {int(s_val)}"
                        res = self.broker._api.searchscrip(exchange=exch_seg, searchtext=search_term)
                        if isinstance(res, dict) and res.get('stat') == 'Ok':
                            for item in res.get('values', []):
                                inst = item.get('instname', '')
                                sym = item.get('symname', '')
                                is_valid_sym = (sym == name) or (name == "SENSEX" and sym in ["BSXOPT", "SENSEX"])
                                if inst == 'OPTIDX' and is_valid_sym:
                                    tsym = item.get('tsym', '')
                                    exd_str = item.get('exd', '')
                                    try:
                                        expiry_dt = datetime.strptime(exd_str, '%d-%b-%Y')
                                    except ValueError:
                                        try:
                                            expiry_dt = datetime.strptime(exd_str, '%d%b%Y')
                                        except ValueError:
                                            continue

                                    strike = float(s_val)

                                    dynamic_opts.append({
                                        'token': str(item['token']),
                                        'symbol': tsym,
                                        'expiry': exd_str,
                                        'expiry_dt': expiry_dt,
                                        'strike': strike
                                    })

                    if dynamic_opts:
                        dyn_df = pd.DataFrame(dynamic_opts)
                        now = datetime.now()
                        valid_dts = [dt for dt in dyn_df['expiry_dt'] if dt.date() >= now.date()]
                        if valid_dts:
                            nearest_exp = min(valid_dts)
                            df = dyn_df[dyn_df['expiry_dt'] == nearest_exp].drop_duplicates(subset=['token']).reset_index(drop=True)
            except Exception as e:
                logger.error(f"Error fetching dynamic option chain via searchscrip: {e}")

        return df
