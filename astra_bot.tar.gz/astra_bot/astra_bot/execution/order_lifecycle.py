import time
import uuid
import logging
from typing import Optional
from astra_bot.execution.trade_context import TradeLeg
from astra_bot.config.settings import EXIT_LIMIT_GRACE_PERIOD_SEC, DEFAULT_PRODUCT_TYPE, NIFTY_LOT_SIZE, SENSEX_LOT_SIZE

logger = logging.getLogger("order_lifecycle")

class OrderLifecycle:
    """
    Abstract Base Class for managing the lifecycle of an order.
    It encapsulates the logic of entering and exiting positions, handling
    pending orders, and applying broker-specific rules.
    """

    def execute_entry(self, leg: TradeLeg) -> bool:
        """
        Executes the entry order for a TradeLeg.
        Returns True if successful, False otherwise.
        """
        raise NotImplementedError

    def execute_exit(self, leg: TradeLeg, reason: str, exit_price: Optional[float] = None) -> bool:
        """
        Executes the market exit for a TradeLeg.
        It must handle pending limit orders according to broker-specific rules.
        Returns True if successful, False otherwise.
        """
        raise NotImplementedError


class PaperOrderLifecycle(OrderLifecycle):
    """
    Simulates instantaneous order execution for paper trading.
    """

    def execute_entry(self, leg: TradeLeg) -> bool:
        leg.status = "OPEN"
        leg.paper_order_id = f"PAPER_{uuid.uuid4().hex[:8].upper()}"
        logger.info(f"[PaperOrderLifecycle] Entry executed for leg {leg.leg_id}. Paper Order ID: {leg.paper_order_id}")
        return True

    def execute_exit(self, leg: TradeLeg, reason: str, exit_price: Optional[float] = None) -> bool:
        if leg.status != "OPEN":
            logger.warning(f"[PaperOrderLifecycle] Attempted to exit leg {leg.leg_id} which is not OPEN.")
            return False
            
        leg.close_leg(exit_price or leg.current_price, reason)
        logger.info(f"[PaperOrderLifecycle] Exit executed for leg {leg.leg_id} at {leg.exit_price}. Reason: {reason}")
        return True


def get_marketable_entry_limit_price(best_ask: float, tick_size: float = 0.05) -> float:
    if best_ask <= 0:
        return 0.0
    buffer = max(3.0, best_ask * 0.025)
    raw_price = best_ask + buffer
    return round(raw_price / tick_size) * tick_size

def get_marketable_exit_limit_price(best_bid: float, tick_size: float = 0.05) -> float:
    if best_bid <= 0:
        return 0.0
    buffer = max(3.0, best_bid * 0.025)
    raw_price = max(0.05, best_bid - buffer)
    return round(raw_price / tick_size) * tick_size

class ShoonyaOrderLifecycle(OrderLifecycle):
    """
    Real-broker Order Lifecycle Manager for Shoonya (NorenApi).
    - Entry Orders: Marketable Limit Order (`price_type="LMT"`, `product_type="N"` NRML).
      Limit Price = Best Ask + max(3.0, Best Ask * 2.5%) rounded to 0.05 tick size.
    - Exit Orders: Single Marketable Limit Order (`price_type="LMT"`, `product_type="N"` NRML).
      Limit Price = Best Bid - max(3.0, Best Bid * 2.5%) rounded to 0.05 tick size.
    """

    def __init__(self, broker_gateway, grace_period_sec: float = EXIT_LIMIT_GRACE_PERIOD_SEC):
        self.broker = broker_gateway
        self.grace_period_sec = grace_period_sec
        self.product_type = "N" # Hardcoded "N" (NRML / Regular) per Shoonya rules for SENSEX/NIFTY options

    def execute_entry(self, leg: TradeLeg) -> bool:
        """
        Executes Marketable Limit Entry Order via Shoonya API.
        """
        try:
            exch_seg = getattr(leg, 'exchange', 'BFO' if 'SENSEX' in leg.symbol else 'NFO')
            qty = leg.quantity * (SENSEX_LOT_SIZE if "SENSEX" in leg.symbol else NIFTY_LOT_SIZE)
            best_ask = leg.current_price
            
            # Fetch live Best Ask if available
            try:
                if hasattr(self.broker, "market_data_provider"):
                    quote = self.broker.market_data_provider.get_quote(exch_seg, str(leg.token))
                    if quote and quote.get("ask", 0) > 0:
                        best_ask = float(quote["ask"])
            except Exception:
                pass

            limit_price = get_marketable_entry_limit_price(best_ask)
            
            logger.info(f"[ShoonyaOrderLifecycle] Placing Marketable Limit Entry Order for {leg.symbol} (Qty: {qty}, Best Ask: Rs {best_ask:.2f}, BUY Limit Px: Rs {limit_price:.2f}, Product: NRML [N])...")
            
            resp = self.broker.place_order(
                buy_or_sell="B",
                product_type=self.product_type,
                exchange=exch_seg,
                tradingsymbol=leg.symbol,
                quantity=qty,
                price_type="LMT",
                price=limit_price
            )
            
            if resp and resp.get("stat") == "Ok" and resp.get("norenordno"):
                ordno = resp["norenordno"]
                leg.broker_order_id = ordno
                leg.status = "OPEN"
                logger.info(f"[ShoonyaOrderLifecycle] Entry Marketable Limit Order Placed! Order ID: {ordno}")
                return True
            else:
                err_msg = resp.get("emsg", "Unknown Broker Error") if isinstance(resp, dict) else str(resp)
                logger.error(f"[ShoonyaOrderLifecycle] Entry Order Failed for {leg.symbol}: {err_msg}")
                return False
        except Exception as e:
            logger.error(f"[ShoonyaOrderLifecycle] Exception in execute_entry: {e}")
            return False

    def execute_exit(self, leg: TradeLeg, reason: str, exit_price: Optional[float] = None) -> bool:
        """
        Executes single Marketable Limit Exit Order for a TradeLeg.
        """
        if leg.status != "OPEN":
            logger.warning(f"[ShoonyaOrderLifecycle] Leg {leg.symbol} is not OPEN. Skipping exit.")
            return False

        exch_seg = getattr(leg, 'exchange', 'BFO' if 'SENSEX' in leg.symbol else 'NFO')
        qty = leg.quantity * (SENSEX_LOT_SIZE if "SENSEX" in leg.symbol else NIFTY_LOT_SIZE)
        token = str(leg.token)
        best_bid = leg.current_price
        
        try:
            if hasattr(self.broker, "market_data_provider"):
                quote = self.broker.market_data_provider.get_quote(exch_seg, token)
                if quote and quote.get("bid", 0) > 0:
                    best_bid = float(quote["bid"])
        except Exception as q_err:
            logger.warning(f"[ShoonyaOrderLifecycle] Quote fetch for exit warning: {q_err}")

        limit_price = get_marketable_exit_limit_price(best_bid)

        logger.info(f"[ShoonyaOrderLifecycle] Initiating Marketable Limit Exit for {leg.symbol} | Reason: {reason} | Best Bid: Rs {best_bid:.2f} | SELL Limit Px: Rs {limit_price:.2f} (Product: NRML [N])")

        try:
            resp = self.broker.place_order(
                buy_or_sell="S",
                product_type=self.product_type,
                exchange=exch_seg,
                tradingsymbol=leg.symbol,
                quantity=qty,
                price_type="LMT",
                price=limit_price
            )
            if resp and resp.get("stat") == "Ok" and resp.get("norenordno"):
                ordno = resp["norenordno"]
                logger.info(f"[ShoonyaOrderLifecycle] Marketable LMT Exit Order Placed! Order ID: {ordno}")
                leg.close_leg(exit_price or limit_price, reason)
                return True
            else:
                err_msg = resp.get("emsg", "Unknown Broker Error") if isinstance(resp, dict) else str(resp)
                logger.error(f"[ShoonyaOrderLifecycle] Marketable LMT Exit Failed: {err_msg}")
                leg.close_leg(exit_price or leg.current_price, f"{reason} (LMT Exit Warning)")
                return False
        except Exception as e:
            logger.error(f"[ShoonyaOrderLifecycle] Exception in execute_exit: {e}")
            leg.close_leg(exit_price or leg.current_price, f"{reason} (Local Exit)")
            return False

