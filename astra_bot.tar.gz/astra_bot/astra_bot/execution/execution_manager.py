import time
import os
import csv
import json
from datetime import datetime, timedelta
import pandas as pd
from astra_bot.core.logger import get_logger
from astra_bot.core.decision_lifecycle import DecisionLifecycle
from astra_bot.execution.capital_engine import CapitalEngine
from astra_bot.execution.order_lifecycle import PaperOrderLifecycle, ShoonyaOrderLifecycle
from astra_bot.config.settings import (
    DATA_DIR,
    INITIAL_PAPER_CAPITAL,
    ENABLE_LIVE_BROKERAGE_EXECUTION,
    DEFAULT_PRODUCT_TYPE,
)
from astra_bot.execution.strike_selector import StrikeSelector
from astra_bot.execution.trade_context import TradeContext, TradeLeg

logger = get_logger("execution_manager")

class ExecutionManager:
    """
    ExecutionManager for KDO Architecture.
    Handles capital allocation, OTM strike selection, Marketable Limit entries,
    and event-driven WebSocket tick exit evaluation.
    """
    def __init__(self, broker_gateway, data_fetcher, history_list=None, order_lifecycle=None):
        self.broker = broker_gateway
        self.data_fetcher = data_fetcher
        
        mode = "LIVE" if ENABLE_LIVE_BROKERAGE_EXECUTION else "PAPER"
        self.capital_engine = CapitalEngine(mode=mode, portfolio_provider=self.broker)
        
        if order_lifecycle:
            self.order_lifecycle = order_lifecycle
        else:
            if ENABLE_LIVE_BROKERAGE_EXECUTION:
                if hasattr(broker_gateway, "get_order_lifecycle"):
                    self.order_lifecycle = broker_gateway.get_order_lifecycle()
                else:
                    self.order_lifecycle = ShoonyaOrderLifecycle(broker_gateway.execution_provider if hasattr(broker_gateway, "execution_provider") else broker_gateway)
                logger.info(f"[ExecutionManager] Configured for REAL MONEY LIVE TRADING via ShoonyaOrderLifecycle (Product: NRML [N], Order Type: Marketable Limit [LMT]).")
            else:
                self.order_lifecycle = PaperOrderLifecycle()
                logger.info("[ExecutionManager] Configured for PAPER TRADING via PaperOrderLifecycle.")
        self.trades_today = 0
        self.trade_context = None
        self.pending_setup = None
        self.strike_cooldowns = {}  # {strike_symbol: cooldown_expiry_dt}
        self.last_trade_date = None
        self.history_list = history_list if history_list is not None else []
        self._option_cache = {}
        
        base_dir = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
        trades_dir = os.path.join(base_dir, "data", "trades")
        os.makedirs(trades_dir, exist_ok=True)
        self.history_file = os.path.join(trades_dir, "trade_history.json")
        self.active_context_file = os.path.join(trades_dir, "active_trade_context.json")
        
        self._load_active_context()
        
        if os.path.exists(self.history_file):
            try:
                with open(self.history_file, 'r', encoding='utf-8') as f:
                    self.history_list = json.load(f)
                    today_str = datetime.now().strftime('%d %b')
                    today_trades = [t for t in self.history_list if t.get('date', '').startswith(today_str)]
                    self.trades_today = len(today_trades)
            except Exception as e:
                logger.error(f"Error loading history file: {e}")
                self.history_list = []

    def _load_active_context(self):
        if os.path.exists(self.active_context_file):
            try:
                with open(self.active_context_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                self.trade_context = TradeContext(
                    signal_type=data["signal_type"],
                    strategy=data["strategy"],
                    index_entry=data["index_entry"],
                    decision_payload=data.get("decision_payload")
                )
                self.trade_context.context_id = data["context_id"]
                self.trade_context.status = data["status"]
                self.trade_context.entry_time = datetime.fromisoformat(data["entry_time"]) if data.get("entry_time") else None
                
                for leg_data in data.get("legs", []):
                    leg = TradeLeg(
                        token=leg_data["token"],
                        symbol=leg_data["symbol"],
                        strike=leg_data["strike"],
                        option_type=leg_data["option_type"],
                        quantity=leg_data["quantity"],
                        entry_price=leg_data["entry_price"],
                        broker_order_id=leg_data.get("broker_order_id"),
                        paper_order_id=leg_data.get("paper_order_id")
                    )
                    leg.leg_id = leg_data["leg_id"]
                    leg.status = leg_data["status"]
                    leg.current_price = leg_data["current_price"]
                    leg.exit_price = leg_data.get("exit_price")
                    leg.pnl = leg_data.get("pnl", 0.0)
                    self.trade_context.add_leg(leg)
                    
                logger.info(f"[ExecutionManager] Restored active TradeContext with {len(self.trade_context.legs)} legs.")
            except Exception as e:
                logger.error(f"[ExecutionManager] Failed to restore TradeContext: {e}")
                self.trade_context = None

    def _save_active_context(self):
        if self.trade_context and self.trade_context.status == "OPEN":
            with open(self.active_context_file, 'w', encoding='utf-8') as f:
                json.dump(self.trade_context.to_dict(), f, indent=4, default=str)
        else:
            if os.path.exists(self.active_context_file):
                os.remove(self.active_context_file)

    def reset_daily(self):
        today = datetime.now().date()
        if self.last_trade_date != today:
            self.trades_today = 0
            self.last_trade_date = today
            self.strike_cooldowns.clear()

    def has_open_trade(self) -> bool:
        return self.trade_context is not None and self.trade_context.has_open_trade()

    def get_instrument_params(self):
        from astra_bot.config.settings import NIFTY_PREMIUM_MIN, NIFTY_PREMIUM_MAX, SENSEX_PREMIUM_MIN, SENSEX_PREMIUM_MAX
        name, exch_seg = self.data_fetcher.get_active_instrument()
        if name == "SENSEX":
            return {"premium_min": SENSEX_PREMIUM_MIN, "premium_max": SENSEX_PREMIUM_MAX, "lot_size": 20, "index_name": "SENSEX"}
        else:
            return {"premium_min": NIFTY_PREMIUM_MIN, "premium_max": NIFTY_PREMIUM_MAX, "lot_size": 65, "index_name": "NIFTY"}

    def execute_kdo_entry(self, signal_type: str, index_price: float, net_delta_velocity: float, decision_payload: dict = None):
        """Executes a KDO entry using Marketable Limit orders."""
        self.reset_daily()
        now = datetime.now()
        
        if self.has_open_trade():
            return
            
        params = self.get_instrument_params()
        weekly_opts = self.data_fetcher.get_weekly_option_tokens()
        
        allocations = StrikeSelector.select_strikes(
            signal_type=signal_type,
            index_price=index_price,
            index_name=params["index_name"],
            weekly_opts=weekly_opts,
            option_cache=self._option_cache,
            available_funds=self.capital_engine.get_available_funds(),
            lot_size=params["lot_size"],
            market_data_provider=self.broker.market_data_provider if hasattr(self.broker, "market_data_provider") else None
        )
        
        if not allocations:
            logger.info("KDO Entry Aborted: No affordable OTM strikes found for Capital.")
            return
            
        opt_row, quantity, ltp = allocations[0]
        symbol = opt_row['symbol']
        
        # Check Strike Cooldown (2-3 minutes post exit per strike)
        if symbol in self.strike_cooldowns and now < self.strike_cooldowns[symbol]:
            logger.info(f"KDO Entry Aborted: Strike {symbol} is in kinematic cooldown until {self.strike_cooldowns[symbol].strftime('%H:%M:%S')}.")
            return

        self.trade_context = TradeContext(
            signal_type=signal_type,
            strategy="KINETIC_DELTA_ORDERFLOW",
            index_entry=index_price,
            decision_payload=decision_payload
        )
        
        token = str(opt_row['token'])
        strike = float(opt_row['strike'])
        leg = TradeLeg(token, symbol, strike, signal_type, quantity, ltp)
        
        if self.order_lifecycle.execute_entry(leg):
            self.trade_context.add_leg(leg)
            self.capital_engine.deduct_funds(ltp * quantity * params["lot_size"])
            self._save_active_context()
            self.trades_today += 1
            logger.info(f"--- KDO TRADE EXECUTED: {quantity} lots of {symbol} at Rs{ltp:.2f} ---")

    def manage_open_trade(self, net_delta_velocity: float = 1.0):
        """
        Event-Driven Open Trade Monitoring (KDO Architecture):
        Evaluates dynamic exit triggers:
        1. Velocity Reversal (V_t <= 0)
        2. Hard SL (-10% on premium)
        Fires a single Marketable Limit Exit Order upon trigger. Zero pending exchange orders.
        """
        if not self.trade_context or self.trade_context.status != "OPEN":
            return
            
        name, exch_seg = self.data_fetcher.get_active_instrument()
        params = self.get_instrument_params()
        
        for leg in self.trade_context.legs:
            if leg.status != "OPEN":
                continue
                
            try:
                res = self.broker.market_data_provider.get_quote(exch_seg, leg.token)
                if res and res.get('ltp', 0.0) > 0:
                    leg.current_price = res['ltp']
            except Exception:
                pass

            entry = leg.entry_price
            current = leg.current_price
            profit_pct = (current - entry) / entry if entry > 0 else 0.0
            
            # Exit Condition 1: Hard -10% Capital Protection Stop
            if profit_pct <= -0.10:
                self._close_all_legs(f"Hard SL Hit (-10% Premium Loss: {profit_pct*100:.1f}%)")
                return

            # Exit Condition 2: Kinematic Orderflow Exhaustion (Velocity Reversal)
            if self.trade_context.signal_type == "CALL" and net_delta_velocity <= 0.0:
                self._close_all_legs(f"Orderflow Exhaustion (CALL Velocity Reversal V_t = {net_delta_velocity:+.0f})")
                return
            elif self.trade_context.signal_type == "PUT" and net_delta_velocity >= 0.0:
                self._close_all_legs(f"Orderflow Exhaustion (PUT Velocity Reversal V_t = {net_delta_velocity:+.0f})")
                return

    def _close_all_legs(self, reason: str):
        """Closes all open legs using a single Marketable Limit Exit Order."""
        if not self.trade_context or self.trade_context.status != "OPEN":
            return
            
        params = self.get_instrument_params()
        now = datetime.now()
        
        total_pnl = 0.0
        for leg in self.trade_context.legs:
            if leg.status == "OPEN":
                if self.order_lifecycle.execute_exit(leg, reason):
                    leg.status = "CLOSED"
                    leg.exit_time = now
                    fill_price = leg.exit_price if leg.exit_price > 0 else leg.current_price
                    leg.pnl = (fill_price - leg.entry_price) * leg.quantity * params["lot_size"]
                    total_pnl += leg.pnl
                    
                    # Set 3-Minute Kinematic Cooldown for this specific strike
                    self.strike_cooldowns[leg.symbol] = now + timedelta(minutes=3)
                    logger.info(f"Closed Leg {leg.symbol}: Entry Rs{leg.entry_price:.2f} -> Exit Rs{fill_price:.2f} | PnL: Rs{leg.pnl:.2f}")

        self.trade_context.status = "CLOSED"
        self.trade_context.exit_time = now
        self._save_active_context()
        
        # Generate Automated Post-Trade Review & Diagnostic Attribution
        feat = self.trade_context.decision_payload or {}
        duration_sec = int((now - self.trade_context.entry_time).total_seconds()) if self.trade_context.entry_time else 0
        is_win = total_pnl >= 0
        
        post_trade_attribution = {
            "outcome": "WINNER" if is_win else "LOSER",
            "pnl_rs": round(total_pnl, 2),
            "trade_duration_sec": duration_sec,
            "exit_reason": reason,
            "entry_z_score": feat.get("z_score", 0.0),
            "entry_flow_duration": feat.get("flow_duration_sec", 0),
            "entry_trade_signer": feat.get("trade_signer", "NEUTRAL"),
            "primary_driver": "SUSTAINED_ACCUMULATION" if feat.get("flow_duration_sec", 0) >= 30 else "SHORT_BURST",
            "diagnostic_summary": f"{'PROFITABLE' if is_win else 'UNPROFITABLE'} {self.trade_context.signal_type} trade ({duration_sec}s) exited via {reason}. Entry Z-Score was {feat.get('z_score', 0.0):.1f} with {feat.get('trade_signer', 'NEUTRAL')} flow."
        }

        # Log to permanent trade history with compact microstructure feature vector & attribution review
        trade_record = {
            "date": now.strftime("%d %b %H:%M:%S"),
            "signal_type": self.trade_context.signal_type,
            "strategy": self.trade_context.strategy,
            "symbol": self.trade_context.legs[0].symbol if self.trade_context.legs else "OPTION",
            "quantity": self.trade_context.legs[0].quantity if self.trade_context.legs else 1,
            "entry_price": self.trade_context.legs[0].entry_price if self.trade_context.legs else 0.0,
            "exit_price": self.trade_context.legs[0].exit_price if self.trade_context.legs else 0.0,
            "net_pl": total_pnl,
            "reason": reason,
            "feature_vector": feat,
            "post_trade_attribution": post_trade_attribution
        }
        self.history_list.append(trade_record)
        try:
            with open(self.history_file, 'w', encoding='utf-8') as f:
                json.dump(self.history_list, f, indent=4, default=str)
        except Exception as e:
            logger.error(f"Failed to save trade history: {e}")

        logger.info(f"=== TRADE CLOSED ({reason}) | Total PnL: Rs{total_pnl:.2f} ===")
