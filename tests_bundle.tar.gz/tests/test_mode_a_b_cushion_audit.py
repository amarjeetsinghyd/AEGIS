import pytest
from datetime import datetime
from unittest.mock import MagicMock
from queue import Queue
from AEGIS.core.price_action_engine import PriceActionEngine, OHLCBar
from AEGIS.aegis_execution_manager import AegisExecutionManager, TradeContext, TradeLeg

def test_trailing_spot_sl_cushion_preserved_on_entry():
    """Verify that on trade entry, trailing_spot_sl does not overwrite the wick cushion."""
    broker = MagicMock()
    data_fetcher = MagicMock()
    data_fetcher.get_active_instrument.return_value = ("NIFTY", "NFO")
    aegis_engine = MagicMock()
    sig_q = Queue()
    em = AegisExecutionManager(broker, data_fetcher, aegis_engine, sig_q)

    ctx = TradeContext(
        signal_type="CALL",
        strategy="AEGIS_GAMMA_BURST",
        index_entry=22466.65,
    )
    ctx.entry_time = datetime.now()
    ctx.candle_low = 22460.85
    ctx.candle_high = 22467.80
    ctx.pillar = 1
    ctx.pa_setup_name = "20_ema_rejection"
    ctx.trailing_spot_sl = 0.0  # Proper entry state!

    leg = TradeLeg("23300", "NIFTY27OCT26C23300", 23300.0, "CALL", 65, 8.15)
    leg.current_price = 8.15
    ctx.add_leg(leg)
    em.trade_context = ctx

    class MockTB:
        def __init__(self):
            self.bars_1m = [
                OHLCBar(ts_start=datetime.now().timestamp(), ts_end=datetime.now().timestamp() + 60,
                        open=22463.15, high=22467.80, low=22460.85, close=22466.00)
            ]
    class MockEngine:
        time_bar_engine = MockTB()
    em.aegis_engine = MockEngine()

    data_fetcher._spot = 22460.0  # Dips below candle_low 22460.85 by 0.85 pts, but inside cushion (cushion = 16.29 * 0.15 = 2.44 pts -> SL = 22458.41)!
    data_fetcher.get_index_ltp = MagicMock(return_value=22460.0)
    em.data_fetcher = data_fetcher

    # Manage trade: spot at 22460.0 MUST NOT trigger exit because 22460.0 > 22458.41!
    em._manage_open_trade()
    assert em.has_open_trade() is True, "Trade was prematurely stopped out because cushion was wiped out!"

def test_mode_a_breakout_from_below_veto():
    """Verify that price coming from below 20 EMA cannot arm a Mode A CALL rejection."""
    pa = PriceActionEngine()
    pa.current_atr_1m = 15.0
    now = 1700000000.0

    # Feed bars below 20 EMA (downtrend / consolidation below 22460)
    for i in range(25):
        b = OHLCBar(
            ts_start=now + i*60,
            ts_end=now + (i+1)*60,
            open=22420.0 + i*0.5,
            high=22425.0 + i*0.5,
            low=22418.0 + i*0.5,
            close=22422.0 + i*0.5,
            volume=50000.0,
        )
        pa.bars_1m.append(b)

    # Now a breakout bar comes from below and crosses 20 EMA upwards
    breakout_bar = OHLCBar(
        ts_start=now + 26*60,
        ts_end=now + 27*60,
        open=22435.0,  # Below 20 EMA (around 22450)
        high=22465.0,
        low=22434.0,
        close=22463.0,  # Closes above/in 20 EMA
        volume=100000.0,
    )
    pa.bars_1m.append(breakout_bar)
    pa._evaluate_mode_a_arming(breakout_bar)

    # Verify that Mode A did NOT arm a CALL rejection on this breakout from below!
    armed = pa._mode_a_armed_setups.get("PILLAR_1_20_EMA")
    assert armed is None or armed.get("direction") != "UP", "Falsely armed CALL rejection on a breakout from below!"


def test_pillar_2_micro_sweep_mode_a_arming_and_piercing():
    """Verify that a valid 5-bar micro-sweep & reclaim arms Mode A and triggers pierce."""
    pa = PriceActionEngine()
    pa.current_atr_1m = 10.0
    now = 1792730040.0  # Exactly divisible by 60 for clean T:00s - T:20s testing

    # 1. Feed 12 base bars forming a clear swing low at 22450.0
    for i in range(12):
        b = OHLCBar(
            ts_start=now + i * 60,
            ts_end=now + (i + 1) * 60,
            open=22460.0,
            high=22465.0,
            low=22450.0 + i * 1.0,
            close=22458.0,
            volume=50000.0,
        )
        pa.bars_1m.append(b)

    # 2. Sweep bar: sweeps prior 5-bar low (22450.0 + 7.0 = 22457.0) down to 22445.0, but reclaims and closes at 22458.0
    # Prior 5 bars lows are 22457.0, 22458.0, 22459.0, 22460.0, 22461.0 (min = 22457.0)
    sweep_bar = OHLCBar(
        ts_start=now + 12 * 60,
        ts_end=now + 13 * 60,
        open=22458.0,
        high=22462.0,
        low=22445.0,  # Swept 22457.0
        close=22460.0, # Reclaimed > 22457.0
        volume=80000.0,
    )
    pa.bars_1m.append(sweep_bar)
    pa._evaluate_mode_a_arming(sweep_bar)

    assert "PILLAR_2_SWEEP_UP" in pa._mode_a_armed_setups
    setup = pa._mode_a_armed_setups["PILLAR_2_SWEEP_UP"]
    assert setup["pillar"] == 2
    assert setup["pa_setup_name"] == "micro_sweep_reclaim"
    assert setup["anchor_high"] == 22462.0

    # 3. Bar N+1 at T+10s: spot pierces anchor_high (22462.0) -> Triggers Mode A Pierce!
    pa.last_price = 22462.5
    ok, reason, details = pa.check_mode_a_pierce("UP", current_time=now + 13 * 60 + 10)
    assert ok is True
    assert details["mode"] == "MODE_A_PIERCE"
    assert details["pillar"] == 2
    assert details["pa_setup_name"] == "micro_sweep_reclaim"


def test_mode_b_breakthrough_pillar_3_and_pillar_4():
    """Verify that Mode B triggers mid-bar (T:08s-T:48s) on Pillar 3 (Box) and Pillar 4 (S/R)."""
    pa = PriceActionEngine()
    pa.current_atr_1m = 10.0
    now = 1792730000.0

    # Feed 5 consolidation bars forming a tight squeeze box (22450 - 22458, rng = 8 <= 1.25*ATR)
    for i in range(5):
        b = OHLCBar(
            ts_start=now + i * 60,
            ts_end=now + (i + 1) * 60,
            open=22452.0,
            high=22458.0,
            low=22450.0,
            close=22455.0,
            volume=50000.0,
        )
        pa.bars_1m.append(b)

    pa.ema_20_1m = 22455.0
    pa.ema_50_1m = 22450.0

    # Forming bar at T:25s breaking out of box_high (22458.0)
    curr_bar = OHLCBar(
        ts_start=now + 5 * 60,
        ts_end=now + 6 * 60,
        open=22454.0,  # Open inside box
        high=22463.0,
        low=22454.0,
        close=22463.0,
        volume=30000.0,
        tick_count=20,
    )
    pa._curr_1m_bar = curr_bar
    pa.last_price = 22462.5  # Spot broken out > 22458 + 2.0
    pa._opt_flow_1m = {
        "call_buy_vol": 100000.0,
        "call_sell_vol": 20000.0,
        "put_buy_vol": 10000.0,
        "put_sell_vol": 5000.0,
    }

    # Tick 1: Awaiting second tick
    ok1, reason1, _ = pa.check_mode_b_breakthrough("UP", current_time=now + 5 * 60 + 25)
    assert ok1 is False
    assert reason1 == "awaiting_second_tick"

    # Tick 2: Consecutive persistence -> Trigger Pillar 3 Volatility Squeeze Breakout!
    ok2, reason2, details2 = pa.check_mode_b_breakthrough("UP", current_time=now + 5 * 60 + 26)
    assert ok2 is True
    assert details2["pillar"] == 3
    assert details2["pa_setup_name"] == "volatility_squeeze_breakout"
    assert details2["mode"] == "MODE_B_INFLIGHT_BREAKTHROUGH"


def test_mode_a_pre_close_early_entry():
    """Verify that Mode A Pre-Close triggers at T:50s-T:58s before candle close."""
    pa = PriceActionEngine()
    pa.current_atr_1m = 10.0
    now = 1792730040.0  # Divisible by 60

    # Feed 15 base uptrend bars
    for i in range(15):
        b = OHLCBar(
            ts_start=now + i * 60,
            ts_end=now + (i + 1) * 60,
            open=22450.0 + i * 1.0,
            high=22455.0 + i * 1.0,
            low=22448.0 + i * 1.0,
            close=22454.0 + i * 1.0,
            volume=50000.0,
        )
        pa.bars_1m.append(b)

    pa.ema_20_1m = 22460.0
    pa.ema_50_1m = 22450.0

    # Forming bar at T:52s touching 20 EMA and showing strong rejection with delta
    forming_bar = OHLCBar(
        ts_start=now + 15 * 60,
        ts_end=now + 16 * 60,
        open=22462.0,
        high=22468.0,
        low=22458.0,  # Tested 20 EMA
        close=22467.0,
        volume=60000.0,
        tick_count=25,
    )
    pa._curr_1m_bar = forming_bar
    pa.last_price = 22467.0  # Spot near high (close_edge >= 0.65)
    pa._opt_flow_1m = {
        "call_buy_vol": 120000.0,
        "call_sell_vol": 30000.0,
        "put_buy_vol": 15000.0,
        "put_sell_vol": 10000.0,
    }

    ok, reason, details = pa.check_mode_a_pre_close("UP", current_time=now + 15 * 60 + 52)
    assert ok is True
    assert details["mode"] == "MODE_A_PRECLOSE"
    assert details["pillar"] == 1
    assert details["pa_setup_name"] == "20_ema_rejection"
    assert details["trigger_sec"] == 52
