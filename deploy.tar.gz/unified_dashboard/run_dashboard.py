from unified_dashboard.dashboard import main

if __name__ == "__main__":
    main()
