# VORTEX Post-09:15 Engine Execution Summary

| Symbol | Total Evals | Hard Gate Passes | Pass Rate | Dominant Regime | Regime Breakdown | Last Timestamp |
| --- | --- | --- | --- | --- | --- | --- |
| BEL | 2563 | 0 | 0.00% | NOISE | NOISE:2554, WHALE:9 | 12:29:56 |
| CANBK | 1899 | 0 | 0.00% | NOISE | NOISE:1894, WHALE:5 | 11:44:59 |
| COALINDIA | 1458 | 0 | 0.00% | NOISE | NOISE:1432, GRIND:26 | 13:05:00 |
| ICICIPRULI | 282 | 0 | 0.00% | NOISE | NOISE:282 | 10:59:00 |
| IDFCFIRSTB | 600 | 0 | 0.00% | NOISE | NOISE:600 | 11:14:54 |
| IRCTC | 87 | 3 | 3.45% | NOISE | NOISE:73, WHALE:14 | 09:59:57 |
| ITC | 1249 | 0 | 0.00% | NOISE | NOISE:1249 | 12:59:58 |
| JIOFIN | 761 | 0 | 0.00% | NOISE | NOISE:761 | 10:29:59 |
| KOTAKBANK | 1692 | 0 | 0.00% | NOISE | NOISE:1691, WHALE:1 | 12:59:57 |
| PNB | 1611 | 0 | 0.00% | NOISE | NOISE:1607, WHALE:4 | 12:59:36 |
| POWERGRID | 202 | 0 | 0.00% | NOISE | NOISE:202 | 09:59:58 |
| SUNPHARMA | 1561 | 0 | 0.00% | NOISE | NOISE:1561 | 12:29:57 |
| TATASTEEL | 10509 | 0 | 0.00% | NOISE | NOISE:10483, GRIND:9, WHALE:17 | 13:05:02 |
| VEDL | 1017 | 0 | 0.00% | NOISE | NOISE:1016, WHALE:1 | 11:44:48 |
| WIPRO | 5792 | 1 | 0.02% | NOISE | NOISE:5702, GRIND:88, WHALE:2 | 12:14:57 |
