import re
from collections import defaultdict
import pandas as pd

LOG_FILE = "vortex-out.log"
OUTPUT_CSV = "vortex_parsed_clean.csv"
SUMMARY_MD = "vortex_summary_by_symbol.md"

records = []
symbol_stats = defaultdict(lambda: {
    "total_evals": 0,
    "passes": 0,
    "regimes": defaultdict(int),
    "last_seen": ""
})

# Flexible extractor pattern
with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        if "[ADAPTIVE_GATE]" not in line:
            continue
        
        # Clean any terminal escape garbage
        clean = re.sub(r"\x1b\[[0-9;]*[a-zA-Z]", "", line).strip()
        
        parts = clean.split()
        if len(parts) < 2:
            continue
            
        date_str = parts[0]
        time_str = parts[1]
        
        # Filter before 09:15:00
        if time_str < "09:15:00":
            continue
            
        # Parse fields safely
        try:
            gate_idx = clean.find("[ADAPTIVE_GATE]")
            payload = clean[gate_idx + len("[ADAPTIVE_GATE]"):].strip()
            chunks = [c.strip() for c in payload.split("|")]
            
            symbol = chunks[0]
            regime_match = re.search(r"Regime:\s*([A-Z]+)", chunks[1])
            regime = regime_match.group(1) if regime_match else "UNKNOWN"
            
            hard_gate = "PASS" if "HARD_GATE: PASS" in clean else "FAIL"
            
            record = {
                "date": date_str,
                "time": time_str,
                "symbol": symbol,
                "regime": regime,
                "gate": hard_gate,
                "raw_details": payload
            }
            records.append(record)
            
            symbol_stats[symbol]["total_evals"] += 1
            symbol_stats[symbol]["last_seen"] = time_str
            symbol_stats[symbol]["regimes"][regime] += 1
            if hard_gate == "PASS":
                symbol_stats[symbol]["passes"] += 1
                
        except Exception:
            continue

df = pd.DataFrame(records)
df.to_csv(OUTPUT_CSV, index=False)
print(f"[SUCCESS] Cleaned {len(df)} records (post 09:15) saved to -> {OUTPUT_CSV}")

# Build summary without external tabulate dependency
summary_rows = []
for sym, stats in sorted(symbol_stats.items()):
    top_regime = max(stats["regimes"], key=stats["regimes"].get) if stats["regimes"] else "UNKNOWN"
    regime_breakdown = ", ".join(f"{k}:{v}" for k, v in stats["regimes"].items())
    pass_rate = f"{(stats['passes'] / stats['total_evals']) * 100:.2f}%" if stats["total_evals"] > 0 else "0%"
    
    summary_rows.append({
        "Symbol": sym,
        "Total Evals": stats["total_evals"],
        "Hard Gate Passes": stats["passes"],
        "Pass Rate": pass_rate,
        "Dominant Regime": top_regime,
        "Regime Breakdown": regime_breakdown,
        "Last Timestamp": stats["last_seen"]
    })

df_summary = pd.DataFrame(summary_rows)

with open(SUMMARY_MD, "w", encoding="utf-8") as f:
    f.write("# VORTEX Post-09:15 Engine Execution Summary\n\n")
    if not df_summary.empty:
        # Standard Markdown Table Generator
        headers = list(df_summary.columns)
        f.write("| " + " | ".join(headers) + " |\n")
        f.write("| " + " | ".join(["---"] * len(headers)) + " |\n")
        for _, row in df_summary.iterrows():
            f.write("| " + " | ".join(str(val) for val in row.values) + " |\n")
    else:
        f.write("No post-09:15 evaluations found.\n")

print(f"[SUCCESS] Symbol-wise summary written to -> {SUMMARY_MD}")